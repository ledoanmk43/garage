﻿namespace GarageManagement
{
    partial class frmDanhMuc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tbKhachHang = new System.Windows.Forms.TabControl();
            this.tpKhachHang = new System.Windows.Forms.TabPage();
            this.btnXemKhachHang = new System.Windows.Forms.Button();
            this.btnSuaKhachHang = new System.Windows.Forms.Button();
            this.btnXoaKhachHang = new System.Windows.Forms.Button();
            this.btnThemKhachHang = new System.Windows.Forms.Button();
            this.dtpNgayGui = new System.Windows.Forms.DateTimePicker();
            this.txtTienNo = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txtDienThoai = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTenKhachHang = new System.Windows.Forms.TextBox();
            this.lbTenMon = new System.Windows.Forms.Label();
            this.txtIDKhachHang = new System.Windows.Forms.TextBox();
            this.lbID = new System.Windows.Forms.Label();
            this.btnTimKhachHang = new System.Windows.Forms.Button();
            this.txtTimKhachHang = new System.Windows.Forms.TextBox();
            this.dgvKhachHang = new System.Windows.Forms.DataGridView();
            this.tpXe = new System.Windows.Forms.TabPage();
            this.dgvKH_Xe = new System.Windows.Forms.DataGridView();
            this.btnTimKH_Xe = new System.Windows.Forms.Button();
            this.txtTimKH_Xe = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.txtHieuXe = new System.Windows.Forms.TextBox();
            this.txtMaXe = new System.Windows.Forms.TextBox();
            this.btnXemXe = new System.Windows.Forms.Button();
            this.btxSuaXe = new System.Windows.Forms.Button();
            this.btnXoaXe = new System.Windows.Forms.Button();
            this.btnThemXe = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.txtIDKH_XE = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.dgvXe = new System.Windows.Forms.DataGridView();
            this.tpKho = new System.Windows.Forms.TabPage();
            this.btnXemKho = new System.Windows.Forms.Button();
            this.btnSuaKho = new System.Windows.Forms.Button();
            this.btnXoaKho = new System.Windows.Forms.Button();
            this.btnThemKho = new System.Windows.Forms.Button();
            this.nmSoLuongVatLieu = new System.Windows.Forms.NumericUpDown();
            this.dtpNgayNhap = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.txtVatLieu = new System.Windows.Forms.TextBox();
            this.txtMaSoVatLieu = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.btnTimKho = new System.Windows.Forms.Button();
            this.txtTimKho = new System.Windows.Forms.TextBox();
            this.dgvKho = new System.Windows.Forms.DataGridView();
            this.tpPhieuSuaChua = new System.Windows.Forms.TabPage();
            this.dgvXe_PSC = new System.Windows.Forms.DataGridView();
            this.btnTimXe_PSC = new System.Windows.Forms.Button();
            this.txtXe_PSC = new System.Windows.Forms.TextBox();
            this.label34 = new System.Windows.Forms.Label();
            this.btnXemPSC = new System.Windows.Forms.Button();
            this.btnSuaPSC = new System.Windows.Forms.Button();
            this.btnXoaPSC = new System.Windows.Forms.Button();
            this.btnThemPSC = new System.Windows.Forms.Button();
            this.label30 = new System.Windows.Forms.Label();
            this.txtTotalPricePSC = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.txtDonGiaPSC = new System.Windows.Forms.TextBox();
            this.dtpNgayTaoPSC = new System.Windows.Forms.DateTimePicker();
            this.label1 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.txtTienCongPSC = new System.Windows.Forms.TextBox();
            this.txtCarnumber_PSC = new System.Windows.Forms.TextBox();
            this.cbVatLieu = new System.Windows.Forms.ComboBox();
            this.txtNoiDungPSC = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.txtIDPSC = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.dgvPSC = new System.Windows.Forms.DataGridView();
            this.tpPhieuThuTien = new System.Windows.Forms.TabPage();
            this.dgvXe_PTT = new System.Windows.Forms.DataGridView();
            this.btnTimKH_PTT = new System.Windows.Forms.Button();
            this.txtXe_PTT = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.btnXemPhieuThuTien = new System.Windows.Forms.Button();
            this.btnSuaPhieuThuTien = new System.Windows.Forms.Button();
            this.btnXoaPhieuThuTien = new System.Windows.Forms.Button();
            this.btnThemPhieuThuTien = new System.Windows.Forms.Button();
            this.label32 = new System.Windows.Forms.Label();
            this.txtSoTienThu = new System.Windows.Forms.TextBox();
            this.dtpNgayTao_PTT = new System.Windows.Forms.DateTimePicker();
            this.label33 = new System.Windows.Forms.Label();
            this.txtBienSo_PTT = new System.Windows.Forms.TextBox();
            this.txtMaKH_PTT = new System.Windows.Forms.TextBox();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.txtIDPTT = new System.Windows.Forms.TextBox();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.dgvPTT = new System.Windows.Forms.DataGridView();
            this.label35 = new System.Windows.Forms.Label();
            this.txtStatus = new System.Windows.Forms.TextBox();
            this.tbKhachHang.SuspendLayout();
            this.tpKhachHang.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhachHang)).BeginInit();
            this.tpXe.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKH_Xe)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe)).BeginInit();
            this.tpKho.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSoLuongVatLieu)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKho)).BeginInit();
            this.tpPhieuSuaChua.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe_PSC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPSC)).BeginInit();
            this.tpPhieuThuTien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe_PTT)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPTT)).BeginInit();
            this.SuspendLayout();
            // 
            // tbKhachHang
            // 
            this.tbKhachHang.Controls.Add(this.tpKhachHang);
            this.tbKhachHang.Controls.Add(this.tpXe);
            this.tbKhachHang.Controls.Add(this.tpKho);
            this.tbKhachHang.Controls.Add(this.tpPhieuSuaChua);
            this.tbKhachHang.Controls.Add(this.tpPhieuThuTien);
            this.tbKhachHang.Location = new System.Drawing.Point(1, 3);
            this.tbKhachHang.Name = "tbKhachHang";
            this.tbKhachHang.SelectedIndex = 0;
            this.tbKhachHang.Size = new System.Drawing.Size(1233, 687);
            this.tbKhachHang.TabIndex = 0;
            // 
            // tpKhachHang
            // 
            this.tpKhachHang.Controls.Add(this.btnXemKhachHang);
            this.tpKhachHang.Controls.Add(this.btnSuaKhachHang);
            this.tpKhachHang.Controls.Add(this.btnXoaKhachHang);
            this.tpKhachHang.Controls.Add(this.btnThemKhachHang);
            this.tpKhachHang.Controls.Add(this.dtpNgayGui);
            this.tpKhachHang.Controls.Add(this.txtTienNo);
            this.tpKhachHang.Controls.Add(this.label6);
            this.tpKhachHang.Controls.Add(this.label5);
            this.tpKhachHang.Controls.Add(this.txtDienThoai);
            this.tpKhachHang.Controls.Add(this.label4);
            this.tpKhachHang.Controls.Add(this.txtDiaChi);
            this.tpKhachHang.Controls.Add(this.label3);
            this.tpKhachHang.Controls.Add(this.txtTenKhachHang);
            this.tpKhachHang.Controls.Add(this.lbTenMon);
            this.tpKhachHang.Controls.Add(this.txtIDKhachHang);
            this.tpKhachHang.Controls.Add(this.lbID);
            this.tpKhachHang.Controls.Add(this.btnTimKhachHang);
            this.tpKhachHang.Controls.Add(this.txtTimKhachHang);
            this.tpKhachHang.Controls.Add(this.dgvKhachHang);
            this.tpKhachHang.Location = new System.Drawing.Point(4, 25);
            this.tpKhachHang.Name = "tpKhachHang";
            this.tpKhachHang.Padding = new System.Windows.Forms.Padding(3);
            this.tpKhachHang.Size = new System.Drawing.Size(1225, 658);
            this.tpKhachHang.TabIndex = 1;
            this.tpKhachHang.Text = "Hồ Sơ Khách Hàng";
            this.tpKhachHang.UseVisualStyleBackColor = true;
            // 
            // btnXemKhachHang
            // 
            this.btnXemKhachHang.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXemKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemKhachHang.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXemKhachHang.Location = new System.Drawing.Point(1051, 296);
            this.btnXemKhachHang.Name = "btnXemKhachHang";
            this.btnXemKhachHang.Size = new System.Drawing.Size(116, 54);
            this.btnXemKhachHang.TabIndex = 128;
            this.btnXemKhachHang.Text = "Xem";
            this.btnXemKhachHang.UseVisualStyleBackColor = false;
            this.btnXemKhachHang.Click += new System.EventHandler(this.btnXemKhachHang_Click);
            // 
            // btnSuaKhachHang
            // 
            this.btnSuaKhachHang.BackColor = System.Drawing.Color.SeaGreen;
            this.btnSuaKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaKhachHang.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSuaKhachHang.Location = new System.Drawing.Point(905, 296);
            this.btnSuaKhachHang.Name = "btnSuaKhachHang";
            this.btnSuaKhachHang.Size = new System.Drawing.Size(116, 54);
            this.btnSuaKhachHang.TabIndex = 127;
            this.btnSuaKhachHang.Text = "Sửa";
            this.btnSuaKhachHang.UseVisualStyleBackColor = false;
            this.btnSuaKhachHang.Click += new System.EventHandler(this.btnSuaKhachHang_Click_1);
            // 
            // btnXoaKhachHang
            // 
            this.btnXoaKhachHang.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXoaKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaKhachHang.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXoaKhachHang.Location = new System.Drawing.Point(758, 296);
            this.btnXoaKhachHang.Name = "btnXoaKhachHang";
            this.btnXoaKhachHang.Size = new System.Drawing.Size(116, 54);
            this.btnXoaKhachHang.TabIndex = 126;
            this.btnXoaKhachHang.Text = "Xóa";
            this.btnXoaKhachHang.UseVisualStyleBackColor = false;
            this.btnXoaKhachHang.Click += new System.EventHandler(this.btnXoaKhachHang_Click_1);
            // 
            // btnThemKhachHang
            // 
            this.btnThemKhachHang.BackColor = System.Drawing.Color.SeaGreen;
            this.btnThemKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemKhachHang.ForeColor = System.Drawing.SystemColors.Control;
            this.btnThemKhachHang.Location = new System.Drawing.Point(610, 296);
            this.btnThemKhachHang.Name = "btnThemKhachHang";
            this.btnThemKhachHang.Size = new System.Drawing.Size(116, 54);
            this.btnThemKhachHang.TabIndex = 125;
            this.btnThemKhachHang.Text = "Thêm";
            this.btnThemKhachHang.UseVisualStyleBackColor = false;
            this.btnThemKhachHang.Click += new System.EventHandler(this.btnThemKhachHang_Click_1);
            // 
            // dtpNgayGui
            // 
            this.dtpNgayGui.CustomFormat = "";
            this.dtpNgayGui.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayGui.Location = new System.Drawing.Point(846, 175);
            this.dtpNgayGui.Name = "dtpNgayGui";
            this.dtpNgayGui.Size = new System.Drawing.Size(303, 27);
            this.dtpNgayGui.TabIndex = 124;
            // 
            // txtTienNo
            // 
            this.txtTienNo.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTienNo.Location = new System.Drawing.Point(846, 230);
            this.txtTienNo.Name = "txtTienNo";
            this.txtTienNo.Size = new System.Drawing.Size(303, 27);
            this.txtTienNo.TabIndex = 123;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.DarkBlue;
            this.label6.Location = new System.Drawing.Point(707, 230);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 24);
            this.label6.TabIndex = 122;
            this.label6.Text = "Tiền nợ:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.DarkBlue;
            this.label5.Location = new System.Drawing.Point(707, 175);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(101, 24);
            this.label5.TabIndex = 121;
            this.label5.Text = "Ngày tạo:";
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDienThoai.Location = new System.Drawing.Point(846, 116);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(303, 27);
            this.txtDienThoai.TabIndex = 120;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.DarkBlue;
            this.label4.Location = new System.Drawing.Point(707, 116);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(112, 24);
            this.label4.TabIndex = 119;
            this.label4.Text = "Điện thoại:";
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi.Location = new System.Drawing.Point(193, 228);
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(303, 27);
            this.txtDiaChi.TabIndex = 112;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.DarkBlue;
            this.label3.Location = new System.Drawing.Point(54, 229);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(81, 24);
            this.label3.TabIndex = 111;
            this.label3.Text = "Địa chỉ:";
            // 
            // txtTenKhachHang
            // 
            this.txtTenKhachHang.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenKhachHang.Location = new System.Drawing.Point(193, 167);
            this.txtTenKhachHang.Name = "txtTenKhachHang";
            this.txtTenKhachHang.Size = new System.Drawing.Size(303, 27);
            this.txtTenKhachHang.TabIndex = 110;
            // 
            // lbTenMon
            // 
            this.lbTenMon.AutoSize = true;
            this.lbTenMon.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTenMon.ForeColor = System.Drawing.Color.DarkBlue;
            this.lbTenMon.Location = new System.Drawing.Point(54, 168);
            this.lbTenMon.Name = "lbTenMon";
            this.lbTenMon.Size = new System.Drawing.Size(52, 24);
            this.lbTenMon.TabIndex = 109;
            this.lbTenMon.Text = "Tên ";
            // 
            // txtIDKhachHang
            // 
            this.txtIDKhachHang.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDKhachHang.Location = new System.Drawing.Point(193, 115);
            this.txtIDKhachHang.Name = "txtIDKhachHang";
            this.txtIDKhachHang.Size = new System.Drawing.Size(303, 27);
            this.txtIDKhachHang.TabIndex = 108;
            // 
            // lbID
            // 
            this.lbID.AutoSize = true;
            this.lbID.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbID.ForeColor = System.Drawing.Color.DarkBlue;
            this.lbID.Location = new System.Drawing.Point(54, 115);
            this.lbID.Name = "lbID";
            this.lbID.Size = new System.Drawing.Size(36, 24);
            this.lbID.TabIndex = 107;
            this.lbID.Text = "ID:";
            // 
            // btnTimKhachHang
            // 
            this.btnTimKhachHang.BackColor = System.Drawing.Color.SeaGreen;
            this.btnTimKhachHang.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKhachHang.ForeColor = System.Drawing.SystemColors.Control;
            this.btnTimKhachHang.Location = new System.Drawing.Point(690, 20);
            this.btnTimKhachHang.Name = "btnTimKhachHang";
            this.btnTimKhachHang.Size = new System.Drawing.Size(108, 56);
            this.btnTimKhachHang.TabIndex = 74;
            this.btnTimKhachHang.Text = "Tìm";
            this.btnTimKhachHang.UseVisualStyleBackColor = false;
            this.btnTimKhachHang.Click += new System.EventHandler(this.btnTimKhachHang_Click);
            // 
            // txtTimKhachHang
            // 
            this.txtTimKhachHang.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKhachHang.Location = new System.Drawing.Point(344, 38);
            this.txtTimKhachHang.Name = "txtTimKhachHang";
            this.txtTimKhachHang.Size = new System.Drawing.Size(324, 27);
            this.txtTimKhachHang.TabIndex = 73;
            // 
            // dgvKhachHang
            // 
            this.dgvKhachHang.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKhachHang.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKhachHang.Location = new System.Drawing.Point(26, 369);
            this.dgvKhachHang.Name = "dgvKhachHang";
            this.dgvKhachHang.RowHeadersWidth = 51;
            this.dgvKhachHang.RowTemplate.Height = 24;
            this.dgvKhachHang.Size = new System.Drawing.Size(1151, 264);
            this.dgvKhachHang.TabIndex = 64;
            // 
            // tpXe
            // 
            this.tpXe.Controls.Add(this.label35);
            this.tpXe.Controls.Add(this.txtStatus);
            this.tpXe.Controls.Add(this.dgvKH_Xe);
            this.tpXe.Controls.Add(this.btnTimKH_Xe);
            this.tpXe.Controls.Add(this.txtTimKH_Xe);
            this.tpXe.Controls.Add(this.label14);
            this.tpXe.Controls.Add(this.label16);
            this.tpXe.Controls.Add(this.label17);
            this.tpXe.Controls.Add(this.txtHieuXe);
            this.tpXe.Controls.Add(this.txtMaXe);
            this.tpXe.Controls.Add(this.btnXemXe);
            this.tpXe.Controls.Add(this.btxSuaXe);
            this.tpXe.Controls.Add(this.btnXoaXe);
            this.tpXe.Controls.Add(this.btnThemXe);
            this.tpXe.Controls.Add(this.label2);
            this.tpXe.Controls.Add(this.txtIDKH_XE);
            this.tpXe.Controls.Add(this.label18);
            this.tpXe.Controls.Add(this.label19);
            this.tpXe.Controls.Add(this.dgvXe);
            this.tpXe.Location = new System.Drawing.Point(4, 25);
            this.tpXe.Name = "tpXe";
            this.tpXe.Padding = new System.Windows.Forms.Padding(3);
            this.tpXe.Size = new System.Drawing.Size(1225, 658);
            this.tpXe.TabIndex = 0;
            this.tpXe.Text = "Xe";
            this.tpXe.UseVisualStyleBackColor = true;
            this.tpXe.Click += new System.EventHandler(this.tpXe_Click);
            // 
            // dgvKH_Xe
            // 
            this.dgvKH_Xe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKH_Xe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKH_Xe.Location = new System.Drawing.Point(41, 291);
            this.dgvKH_Xe.Name = "dgvKH_Xe";
            this.dgvKH_Xe.RowHeadersWidth = 51;
            this.dgvKH_Xe.RowTemplate.Height = 24;
            this.dgvKH_Xe.Size = new System.Drawing.Size(518, 342);
            this.dgvKH_Xe.TabIndex = 136;
            // 
            // btnTimKH_Xe
            // 
            this.btnTimKH_Xe.BackColor = System.Drawing.Color.SeaGreen;
            this.btnTimKH_Xe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKH_Xe.ForeColor = System.Drawing.SystemColors.Control;
            this.btnTimKH_Xe.Location = new System.Drawing.Point(447, 207);
            this.btnTimKH_Xe.Name = "btnTimKH_Xe";
            this.btnTimKH_Xe.Size = new System.Drawing.Size(112, 58);
            this.btnTimKH_Xe.TabIndex = 135;
            this.btnTimKH_Xe.Text = "Tìm KH";
            this.btnTimKH_Xe.UseVisualStyleBackColor = false;
            this.btnTimKH_Xe.Click += new System.EventHandler(this.btnTimKH_Xe_Click);
            // 
            // txtTimKH_Xe
            // 
            this.txtTimKH_Xe.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKH_Xe.Location = new System.Drawing.Point(222, 221);
            this.txtTimKH_Xe.Name = "txtTimKH_Xe";
            this.txtTimKH_Xe.Size = new System.Drawing.Size(207, 27);
            this.txtTimKH_Xe.TabIndex = 134;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.DarkBlue;
            this.label14.Location = new System.Drawing.Point(37, 222);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(169, 24);
            this.label14.TabIndex = 133;
            this.label14.Text = "Tìm khách hàng:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.DarkBlue;
            this.label16.Location = new System.Drawing.Point(37, 118);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(89, 24);
            this.label16.TabIndex = 132;
            this.label16.Text = "Hiệu Xe:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.DarkBlue;
            this.label17.Location = new System.Drawing.Point(659, 54);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(95, 24);
            this.label17.TabIndex = 131;
            this.label17.Text = "Mã số xe";
            // 
            // txtHieuXe
            // 
            this.txtHieuXe.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHieuXe.Location = new System.Drawing.Point(208, 117);
            this.txtHieuXe.Name = "txtHieuXe";
            this.txtHieuXe.Size = new System.Drawing.Size(303, 27);
            this.txtHieuXe.TabIndex = 130;
            // 
            // txtMaXe
            // 
            this.txtMaXe.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaXe.Location = new System.Drawing.Point(830, 54);
            this.txtMaXe.Name = "txtMaXe";
            this.txtMaXe.Size = new System.Drawing.Size(303, 27);
            this.txtMaXe.TabIndex = 129;
            // 
            // btnXemXe
            // 
            this.btnXemXe.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXemXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemXe.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXemXe.Location = new System.Drawing.Point(1046, 207);
            this.btnXemXe.Name = "btnXemXe";
            this.btnXemXe.Size = new System.Drawing.Size(103, 58);
            this.btnXemXe.TabIndex = 128;
            this.btnXemXe.Text = "Xem";
            this.btnXemXe.UseVisualStyleBackColor = false;
            this.btnXemXe.Click += new System.EventHandler(this.btnXemXe_Click_1);
            // 
            // btxSuaXe
            // 
            this.btxSuaXe.BackColor = System.Drawing.Color.SeaGreen;
            this.btxSuaXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btxSuaXe.ForeColor = System.Drawing.SystemColors.Control;
            this.btxSuaXe.Location = new System.Drawing.Point(919, 207);
            this.btxSuaXe.Name = "btxSuaXe";
            this.btxSuaXe.Size = new System.Drawing.Size(103, 58);
            this.btxSuaXe.TabIndex = 127;
            this.btxSuaXe.Text = "Sửa";
            this.btxSuaXe.UseVisualStyleBackColor = false;
            this.btxSuaXe.Click += new System.EventHandler(this.btxSuaXe_Click_1);
            // 
            // btnXoaXe
            // 
            this.btnXoaXe.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXoaXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaXe.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXoaXe.Location = new System.Drawing.Point(789, 207);
            this.btnXoaXe.Name = "btnXoaXe";
            this.btnXoaXe.Size = new System.Drawing.Size(103, 58);
            this.btnXoaXe.TabIndex = 126;
            this.btnXoaXe.Text = "Xóa";
            this.btnXoaXe.UseVisualStyleBackColor = false;
            this.btnXoaXe.Click += new System.EventHandler(this.btnXoaXe_Click_1);
            // 
            // btnThemXe
            // 
            this.btnThemXe.BackColor = System.Drawing.Color.SeaGreen;
            this.btnThemXe.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemXe.ForeColor = System.Drawing.SystemColors.Control;
            this.btnThemXe.Location = new System.Drawing.Point(651, 207);
            this.btnThemXe.Name = "btnThemXe";
            this.btnThemXe.Size = new System.Drawing.Size(103, 58);
            this.btnThemXe.TabIndex = 125;
            this.btnThemXe.Text = "Thêm";
            this.btnThemXe.UseVisualStyleBackColor = false;
            this.btnThemXe.Click += new System.EventHandler(this.btnThemXe_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.DarkBlue;
            this.label2.Location = new System.Drawing.Point(37, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(150, 24);
            this.label2.TabIndex = 124;
            this.label2.Text = "Id khách hàng:";
            // 
            // txtIDKH_XE
            // 
            this.txtIDKH_XE.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDKH_XE.Location = new System.Drawing.Point(208, 53);
            this.txtIDKH_XE.Name = "txtIDKH_XE";
            this.txtIDKH_XE.Size = new System.Drawing.Size(303, 27);
            this.txtIDKH_XE.TabIndex = 123;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.DarkBlue;
            this.label18.Location = new System.Drawing.Point(37, 159);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 24);
            this.label18.TabIndex = 119;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.DarkBlue;
            this.label19.Location = new System.Drawing.Point(55, 98);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(0, 24);
            this.label19.TabIndex = 117;
            // 
            // dgvXe
            // 
            this.dgvXe.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvXe.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXe.Location = new System.Drawing.Point(645, 291);
            this.dgvXe.Name = "dgvXe";
            this.dgvXe.RowHeadersWidth = 51;
            this.dgvXe.RowTemplate.Height = 24;
            this.dgvXe.Size = new System.Drawing.Size(504, 342);
            this.dgvXe.TabIndex = 102;
            // 
            // tpKho
            // 
            this.tpKho.Controls.Add(this.btnXemKho);
            this.tpKho.Controls.Add(this.btnSuaKho);
            this.tpKho.Controls.Add(this.btnXoaKho);
            this.tpKho.Controls.Add(this.btnThemKho);
            this.tpKho.Controls.Add(this.nmSoLuongVatLieu);
            this.tpKho.Controls.Add(this.dtpNgayNhap);
            this.tpKho.Controls.Add(this.label15);
            this.tpKho.Controls.Add(this.label10);
            this.tpKho.Controls.Add(this.label7);
            this.tpKho.Controls.Add(this.label8);
            this.tpKho.Controls.Add(this.label13);
            this.tpKho.Controls.Add(this.label9);
            this.tpKho.Controls.Add(this.txtVatLieu);
            this.tpKho.Controls.Add(this.txtMaSoVatLieu);
            this.tpKho.Controls.Add(this.label11);
            this.tpKho.Controls.Add(this.label12);
            this.tpKho.Controls.Add(this.btnTimKho);
            this.tpKho.Controls.Add(this.txtTimKho);
            this.tpKho.Controls.Add(this.dgvKho);
            this.tpKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tpKho.Location = new System.Drawing.Point(4, 25);
            this.tpKho.Name = "tpKho";
            this.tpKho.Padding = new System.Windows.Forms.Padding(3);
            this.tpKho.Size = new System.Drawing.Size(1225, 658);
            this.tpKho.TabIndex = 2;
            this.tpKho.Text = "Kho vật tư phụ tùng";
            this.tpKho.UseVisualStyleBackColor = true;
            // 
            // btnXemKho
            // 
            this.btnXemKho.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXemKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemKho.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXemKho.Location = new System.Drawing.Point(1047, 292);
            this.btnXemKho.Name = "btnXemKho";
            this.btnXemKho.Size = new System.Drawing.Size(108, 63);
            this.btnXemKho.TabIndex = 129;
            this.btnXemKho.Text = "Xem";
            this.btnXemKho.UseVisualStyleBackColor = false;
            this.btnXemKho.Click += new System.EventHandler(this.btnXemKho_Click_1);
            // 
            // btnSuaKho
            // 
            this.btnSuaKho.BackColor = System.Drawing.Color.SeaGreen;
            this.btnSuaKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaKho.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSuaKho.Location = new System.Drawing.Point(902, 292);
            this.btnSuaKho.Name = "btnSuaKho";
            this.btnSuaKho.Size = new System.Drawing.Size(108, 63);
            this.btnSuaKho.TabIndex = 128;
            this.btnSuaKho.Text = "Sửa";
            this.btnSuaKho.UseVisualStyleBackColor = false;
            this.btnSuaKho.Click += new System.EventHandler(this.btnSuaKho_Click_1);
            // 
            // btnXoaKho
            // 
            this.btnXoaKho.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXoaKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaKho.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXoaKho.Location = new System.Drawing.Point(750, 292);
            this.btnXoaKho.Name = "btnXoaKho";
            this.btnXoaKho.Size = new System.Drawing.Size(108, 63);
            this.btnXoaKho.TabIndex = 127;
            this.btnXoaKho.Text = "Xóa";
            this.btnXoaKho.UseVisualStyleBackColor = false;
            this.btnXoaKho.Click += new System.EventHandler(this.btnXoaKho_Click_1);
            // 
            // btnThemKho
            // 
            this.btnThemKho.BackColor = System.Drawing.Color.SeaGreen;
            this.btnThemKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemKho.ForeColor = System.Drawing.SystemColors.Control;
            this.btnThemKho.Location = new System.Drawing.Point(599, 292);
            this.btnThemKho.Name = "btnThemKho";
            this.btnThemKho.Size = new System.Drawing.Size(108, 63);
            this.btnThemKho.TabIndex = 126;
            this.btnThemKho.Text = "Thêm";
            this.btnThemKho.UseVisualStyleBackColor = false;
            this.btnThemKho.Click += new System.EventHandler(this.btnThemKho_Click);
            // 
            // nmSoLuongVatLieu
            // 
            this.nmSoLuongVatLieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.nmSoLuongVatLieu.Location = new System.Drawing.Point(844, 146);
            this.nmSoLuongVatLieu.Name = "nmSoLuongVatLieu";
            this.nmSoLuongVatLieu.Size = new System.Drawing.Size(303, 27);
            this.nmSoLuongVatLieu.TabIndex = 125;
            // 
            // dtpNgayNhap
            // 
            this.dtpNgayNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayNhap.Location = new System.Drawing.Point(844, 208);
            this.dtpNgayNhap.Name = "dtpNgayNhap";
            this.dtpNgayNhap.Size = new System.Drawing.Size(303, 27);
            this.dtpNgayNhap.TabIndex = 123;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.DarkBlue;
            this.label15.Location = new System.Drawing.Point(646, 210);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(118, 24);
            this.label15.TabIndex = 121;
            this.label15.Text = "Ngày nhập:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.DarkBlue;
            this.label10.Location = new System.Drawing.Point(646, 144);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(179, 24);
            this.label10.TabIndex = 120;
            this.label10.Text = "Số lượng vật liệu:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.DarkBlue;
            this.label7.Location = new System.Drawing.Point(1106, 205);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(0, 24);
            this.label7.TabIndex = 119;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.DarkBlue;
            this.label8.Location = new System.Drawing.Point(1106, 144);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(0, 24);
            this.label8.TabIndex = 118;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.DarkBlue;
            this.label13.Location = new System.Drawing.Point(30, 209);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(127, 24);
            this.label13.TabIndex = 111;
            this.label13.Text = "Tên vật liệu:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.DarkBlue;
            this.label9.Location = new System.Drawing.Point(30, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(148, 24);
            this.label9.TabIndex = 110;
            this.label9.Text = "Mã số vật liệu:";
            // 
            // txtVatLieu
            // 
            this.txtVatLieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtVatLieu.Location = new System.Drawing.Point(228, 208);
            this.txtVatLieu.Name = "txtVatLieu";
            this.txtVatLieu.Size = new System.Drawing.Size(303, 27);
            this.txtVatLieu.TabIndex = 109;
            // 
            // txtMaSoVatLieu
            // 
            this.txtMaSoVatLieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaSoVatLieu.Location = new System.Drawing.Point(228, 144);
            this.txtMaSoVatLieu.Name = "txtMaSoVatLieu";
            this.txtMaSoVatLieu.Size = new System.Drawing.Size(303, 27);
            this.txtMaSoVatLieu.TabIndex = 108;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.DarkBlue;
            this.label11.Location = new System.Drawing.Point(595, 229);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(0, 24);
            this.label11.TabIndex = 93;
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.DarkBlue;
            this.label12.Location = new System.Drawing.Point(595, 170);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(0, 24);
            this.label12.TabIndex = 91;
            // 
            // btnTimKho
            // 
            this.btnTimKho.BackColor = System.Drawing.Color.SeaGreen;
            this.btnTimKho.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKho.ForeColor = System.Drawing.SystemColors.Control;
            this.btnTimKho.Location = new System.Drawing.Point(723, 22);
            this.btnTimKho.Name = "btnTimKho";
            this.btnTimKho.Size = new System.Drawing.Size(108, 65);
            this.btnTimKho.TabIndex = 90;
            this.btnTimKho.Text = "Tìm";
            this.btnTimKho.UseVisualStyleBackColor = false;
            this.btnTimKho.Click += new System.EventHandler(this.btnTimKho_Click);
            // 
            // txtTimKho
            // 
            this.txtTimKho.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimKho.Location = new System.Drawing.Point(344, 40);
            this.txtTimKho.Name = "txtTimKho";
            this.txtTimKho.Size = new System.Drawing.Size(338, 27);
            this.txtTimKho.TabIndex = 89;
            // 
            // dgvKho
            // 
            this.dgvKho.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvKho.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvKho.Location = new System.Drawing.Point(34, 361);
            this.dgvKho.Name = "dgvKho";
            this.dgvKho.RowHeadersWidth = 51;
            this.dgvKho.RowTemplate.Height = 24;
            this.dgvKho.Size = new System.Drawing.Size(1128, 272);
            this.dgvKho.TabIndex = 84;
            // 
            // tpPhieuSuaChua
            // 
            this.tpPhieuSuaChua.Controls.Add(this.dgvXe_PSC);
            this.tpPhieuSuaChua.Controls.Add(this.btnTimXe_PSC);
            this.tpPhieuSuaChua.Controls.Add(this.txtXe_PSC);
            this.tpPhieuSuaChua.Controls.Add(this.label34);
            this.tpPhieuSuaChua.Controls.Add(this.btnXemPSC);
            this.tpPhieuSuaChua.Controls.Add(this.btnSuaPSC);
            this.tpPhieuSuaChua.Controls.Add(this.btnXoaPSC);
            this.tpPhieuSuaChua.Controls.Add(this.btnThemPSC);
            this.tpPhieuSuaChua.Controls.Add(this.label30);
            this.tpPhieuSuaChua.Controls.Add(this.txtTotalPricePSC);
            this.tpPhieuSuaChua.Controls.Add(this.label29);
            this.tpPhieuSuaChua.Controls.Add(this.txtDonGiaPSC);
            this.tpPhieuSuaChua.Controls.Add(this.dtpNgayTaoPSC);
            this.tpPhieuSuaChua.Controls.Add(this.label1);
            this.tpPhieuSuaChua.Controls.Add(this.label28);
            this.tpPhieuSuaChua.Controls.Add(this.txtTienCongPSC);
            this.tpPhieuSuaChua.Controls.Add(this.txtCarnumber_PSC);
            this.tpPhieuSuaChua.Controls.Add(this.cbVatLieu);
            this.tpPhieuSuaChua.Controls.Add(this.txtNoiDungPSC);
            this.tpPhieuSuaChua.Controls.Add(this.label27);
            this.tpPhieuSuaChua.Controls.Add(this.label20);
            this.tpPhieuSuaChua.Controls.Add(this.label21);
            this.tpPhieuSuaChua.Controls.Add(this.label22);
            this.tpPhieuSuaChua.Controls.Add(this.txtIDPSC);
            this.tpPhieuSuaChua.Controls.Add(this.label23);
            this.tpPhieuSuaChua.Controls.Add(this.label24);
            this.tpPhieuSuaChua.Controls.Add(this.label25);
            this.tpPhieuSuaChua.Controls.Add(this.label26);
            this.tpPhieuSuaChua.Controls.Add(this.dgvPSC);
            this.tpPhieuSuaChua.Location = new System.Drawing.Point(4, 25);
            this.tpPhieuSuaChua.Name = "tpPhieuSuaChua";
            this.tpPhieuSuaChua.Padding = new System.Windows.Forms.Padding(3);
            this.tpPhieuSuaChua.Size = new System.Drawing.Size(1225, 658);
            this.tpPhieuSuaChua.TabIndex = 3;
            this.tpPhieuSuaChua.Text = "Phiếu Sửa Chữa";
            this.tpPhieuSuaChua.UseVisualStyleBackColor = true;
            // 
            // dgvXe_PSC
            // 
            this.dgvXe_PSC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvXe_PSC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXe_PSC.Location = new System.Drawing.Point(26, 368);
            this.dgvXe_PSC.Name = "dgvXe_PSC";
            this.dgvXe_PSC.RowHeadersWidth = 51;
            this.dgvXe_PSC.RowTemplate.Height = 24;
            this.dgvXe_PSC.Size = new System.Drawing.Size(490, 265);
            this.dgvXe_PSC.TabIndex = 174;
            // 
            // btnTimXe_PSC
            // 
            this.btnTimXe_PSC.BackColor = System.Drawing.Color.SeaGreen;
            this.btnTimXe_PSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimXe_PSC.ForeColor = System.Drawing.SystemColors.Control;
            this.btnTimXe_PSC.Location = new System.Drawing.Point(411, 311);
            this.btnTimXe_PSC.Name = "btnTimXe_PSC";
            this.btnTimXe_PSC.Size = new System.Drawing.Size(105, 51);
            this.btnTimXe_PSC.TabIndex = 173;
            this.btnTimXe_PSC.Text = "Tìm Xe";
            this.btnTimXe_PSC.UseVisualStyleBackColor = false;
            this.btnTimXe_PSC.Click += new System.EventHandler(this.btnTimXe_PSC_Click);
            // 
            // txtXe_PSC
            // 
            this.txtXe_PSC.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXe_PSC.Location = new System.Drawing.Point(120, 321);
            this.txtXe_PSC.Name = "txtXe_PSC";
            this.txtXe_PSC.Size = new System.Drawing.Size(276, 27);
            this.txtXe_PSC.TabIndex = 172;
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.DarkBlue;
            this.label34.Location = new System.Drawing.Point(33, 322);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(81, 24);
            this.label34.TabIndex = 171;
            this.label34.Text = "Tìm xe:";
            // 
            // btnXemPSC
            // 
            this.btnXemPSC.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXemPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemPSC.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXemPSC.Location = new System.Drawing.Point(1053, 309);
            this.btnXemPSC.Name = "btnXemPSC";
            this.btnXemPSC.Size = new System.Drawing.Size(108, 53);
            this.btnXemPSC.TabIndex = 170;
            this.btnXemPSC.Text = "Xem";
            this.btnXemPSC.UseVisualStyleBackColor = false;
            this.btnXemPSC.Click += new System.EventHandler(this.btnXemPSC_Click_1);
            // 
            // btnSuaPSC
            // 
            this.btnSuaPSC.BackColor = System.Drawing.Color.SeaGreen;
            this.btnSuaPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaPSC.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSuaPSC.Location = new System.Drawing.Point(921, 309);
            this.btnSuaPSC.Name = "btnSuaPSC";
            this.btnSuaPSC.Size = new System.Drawing.Size(108, 53);
            this.btnSuaPSC.TabIndex = 169;
            this.btnSuaPSC.Text = "Sửa";
            this.btnSuaPSC.UseVisualStyleBackColor = false;
            this.btnSuaPSC.Click += new System.EventHandler(this.btnSuaPSC_Click_1);
            // 
            // btnXoaPSC
            // 
            this.btnXoaPSC.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXoaPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaPSC.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXoaPSC.Location = new System.Drawing.Point(786, 309);
            this.btnXoaPSC.Name = "btnXoaPSC";
            this.btnXoaPSC.Size = new System.Drawing.Size(108, 53);
            this.btnXoaPSC.TabIndex = 168;
            this.btnXoaPSC.Text = "Xóa";
            this.btnXoaPSC.UseVisualStyleBackColor = false;
            this.btnXoaPSC.Click += new System.EventHandler(this.btnXoaPSC_Click_1);
            // 
            // btnThemPSC
            // 
            this.btnThemPSC.BackColor = System.Drawing.Color.SeaGreen;
            this.btnThemPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemPSC.ForeColor = System.Drawing.SystemColors.Control;
            this.btnThemPSC.Location = new System.Drawing.Point(646, 309);
            this.btnThemPSC.Name = "btnThemPSC";
            this.btnThemPSC.Size = new System.Drawing.Size(108, 53);
            this.btnThemPSC.TabIndex = 167;
            this.btnThemPSC.Text = "Thêm";
            this.btnThemPSC.UseVisualStyleBackColor = false;
            this.btnThemPSC.Click += new System.EventHandler(this.btnThemPSC_Click_1);
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Arial", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.Red;
            this.label30.Location = new System.Drawing.Point(624, 231);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(130, 29);
            this.label30.TabIndex = 166;
            this.label30.Text = "Tổng tiền:";
            // 
            // txtTotalPricePSC
            // 
            this.txtTotalPricePSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTotalPricePSC.Location = new System.Drawing.Point(821, 232);
            this.txtTotalPricePSC.Name = "txtTotalPricePSC";
            this.txtTotalPricePSC.ReadOnly = true;
            this.txtTotalPricePSC.Size = new System.Drawing.Size(335, 30);
            this.txtTotalPricePSC.TabIndex = 165;
            this.txtTotalPricePSC.Text = "0";
            this.txtTotalPricePSC.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.DarkBlue;
            this.label29.Location = new System.Drawing.Point(625, 104);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(91, 24);
            this.label29.TabIndex = 164;
            this.label29.Text = "Đơn giá:";
            // 
            // txtDonGiaPSC
            // 
            this.txtDonGiaPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDonGiaPSC.Location = new System.Drawing.Point(821, 105);
            this.txtDonGiaPSC.Name = "txtDonGiaPSC";
            this.txtDonGiaPSC.Size = new System.Drawing.Size(335, 27);
            this.txtDonGiaPSC.TabIndex = 163;
            // 
            // dtpNgayTaoPSC
            // 
            this.dtpNgayTaoPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayTaoPSC.Location = new System.Drawing.Point(821, 43);
            this.dtpNgayTaoPSC.Name = "dtpNgayTaoPSC";
            this.dtpNgayTaoPSC.Size = new System.Drawing.Size(335, 27);
            this.dtpNgayTaoPSC.TabIndex = 162;
            this.dtpNgayTaoPSC.Value = new System.DateTime(2019, 12, 16, 0, 0, 0, 0);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.DarkBlue;
            this.label1.Location = new System.Drawing.Point(625, 45);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(159, 24);
            this.label1.TabIndex = 161;
            this.label1.Text = "Ngày tạo phiếu:";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.DarkBlue;
            this.label28.Location = new System.Drawing.Point(625, 170);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(111, 24);
            this.label28.TabIndex = 160;
            this.label28.Text = "Tiền công:";
            // 
            // txtTienCongPSC
            // 
            this.txtTienCongPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTienCongPSC.Location = new System.Drawing.Point(821, 171);
            this.txtTienCongPSC.Name = "txtTienCongPSC";
            this.txtTienCongPSC.Size = new System.Drawing.Size(335, 27);
            this.txtTienCongPSC.TabIndex = 159;
            // 
            // txtCarnumber_PSC
            // 
            this.txtCarnumber_PSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCarnumber_PSC.Location = new System.Drawing.Point(263, 106);
            this.txtCarnumber_PSC.Name = "txtCarnumber_PSC";
            this.txtCarnumber_PSC.Size = new System.Drawing.Size(307, 27);
            this.txtCarnumber_PSC.TabIndex = 158;
            // 
            // cbVatLieu
            // 
            this.cbVatLieu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbVatLieu.FormattingEnabled = true;
            this.cbVatLieu.Location = new System.Drawing.Point(263, 170);
            this.cbVatLieu.Name = "cbVatLieu";
            this.cbVatLieu.Size = new System.Drawing.Size(307, 28);
            this.cbVatLieu.TabIndex = 157;
            // 
            // txtNoiDungPSC
            // 
            this.txtNoiDungPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtNoiDungPSC.Location = new System.Drawing.Point(263, 231);
            this.txtNoiDungPSC.Name = "txtNoiDungPSC";
            this.txtNoiDungPSC.Size = new System.Drawing.Size(307, 27);
            this.txtNoiDungPSC.TabIndex = 156;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.DarkBlue;
            this.label27.Location = new System.Drawing.Point(33, 231);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(102, 24);
            this.label27.TabIndex = 147;
            this.label27.Text = "Nội dung:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.DarkBlue;
            this.label20.Location = new System.Drawing.Point(33, 170);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(87, 24);
            this.label20.TabIndex = 146;
            this.label20.Text = "Vật liệu:";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.DarkBlue;
            this.label21.Location = new System.Drawing.Point(33, 109);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(164, 24);
            this.label21.TabIndex = 145;
            this.label21.Text = "Biển số xe sửa :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.DarkBlue;
            this.label22.Location = new System.Drawing.Point(33, 45);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(205, 24);
            this.label22.TabIndex = 144;
            this.label22.Text = "Mã phiếu sữa chữa :";
            // 
            // txtIDPSC
            // 
            this.txtIDPSC.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDPSC.Location = new System.Drawing.Point(263, 45);
            this.txtIDPSC.Name = "txtIDPSC";
            this.txtIDPSC.Size = new System.Drawing.Size(307, 27);
            this.txtIDPSC.TabIndex = 143;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.DarkBlue;
            this.label23.Location = new System.Drawing.Point(600, 298);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(0, 24);
            this.label23.TabIndex = 121;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.DarkBlue;
            this.label24.Location = new System.Drawing.Point(589, 229);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(0, 24);
            this.label24.TabIndex = 119;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.DarkBlue;
            this.label25.Location = new System.Drawing.Point(589, 163);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(0, 24);
            this.label25.TabIndex = 117;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.DarkBlue;
            this.label26.Location = new System.Drawing.Point(589, 104);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(0, 24);
            this.label26.TabIndex = 116;
            // 
            // dgvPSC
            // 
            this.dgvPSC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPSC.Location = new System.Drawing.Point(550, 368);
            this.dgvPSC.Name = "dgvPSC";
            this.dgvPSC.RowHeadersWidth = 51;
            this.dgvPSC.RowTemplate.Height = 24;
            this.dgvPSC.Size = new System.Drawing.Size(612, 265);
            this.dgvPSC.TabIndex = 109;
            // 
            // tpPhieuThuTien
            // 
            this.tpPhieuThuTien.Controls.Add(this.dgvXe_PTT);
            this.tpPhieuThuTien.Controls.Add(this.btnTimKH_PTT);
            this.tpPhieuThuTien.Controls.Add(this.txtXe_PTT);
            this.tpPhieuThuTien.Controls.Add(this.label31);
            this.tpPhieuThuTien.Controls.Add(this.btnXemPhieuThuTien);
            this.tpPhieuThuTien.Controls.Add(this.btnSuaPhieuThuTien);
            this.tpPhieuThuTien.Controls.Add(this.btnXoaPhieuThuTien);
            this.tpPhieuThuTien.Controls.Add(this.btnThemPhieuThuTien);
            this.tpPhieuThuTien.Controls.Add(this.label32);
            this.tpPhieuThuTien.Controls.Add(this.txtSoTienThu);
            this.tpPhieuThuTien.Controls.Add(this.dtpNgayTao_PTT);
            this.tpPhieuThuTien.Controls.Add(this.label33);
            this.tpPhieuThuTien.Controls.Add(this.txtBienSo_PTT);
            this.tpPhieuThuTien.Controls.Add(this.txtMaKH_PTT);
            this.tpPhieuThuTien.Controls.Add(this.label36);
            this.tpPhieuThuTien.Controls.Add(this.label37);
            this.tpPhieuThuTien.Controls.Add(this.label38);
            this.tpPhieuThuTien.Controls.Add(this.txtIDPTT);
            this.tpPhieuThuTien.Controls.Add(this.label41);
            this.tpPhieuThuTien.Controls.Add(this.label42);
            this.tpPhieuThuTien.Controls.Add(this.label39);
            this.tpPhieuThuTien.Controls.Add(this.label40);
            this.tpPhieuThuTien.Controls.Add(this.dgvPTT);
            this.tpPhieuThuTien.Location = new System.Drawing.Point(4, 25);
            this.tpPhieuThuTien.Name = "tpPhieuThuTien";
            this.tpPhieuThuTien.Padding = new System.Windows.Forms.Padding(3);
            this.tpPhieuThuTien.Size = new System.Drawing.Size(1225, 658);
            this.tpPhieuThuTien.TabIndex = 4;
            this.tpPhieuThuTien.Text = "Phiếu Thu Tiền";
            this.tpPhieuThuTien.UseVisualStyleBackColor = true;
            // 
            // dgvXe_PTT
            // 
            this.dgvXe_PTT.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvXe_PTT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXe_PTT.Location = new System.Drawing.Point(27, 329);
            this.dgvXe_PTT.Name = "dgvXe_PTT";
            this.dgvXe_PTT.RowHeadersWidth = 51;
            this.dgvXe_PTT.RowTemplate.Height = 24;
            this.dgvXe_PTT.Size = new System.Drawing.Size(482, 301);
            this.dgvXe_PTT.TabIndex = 211;
            // 
            // btnTimKH_PTT
            // 
            this.btnTimKH_PTT.BackColor = System.Drawing.Color.SeaGreen;
            this.btnTimKH_PTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimKH_PTT.ForeColor = System.Drawing.SystemColors.Control;
            this.btnTimKH_PTT.Location = new System.Drawing.Point(411, 259);
            this.btnTimKH_PTT.Name = "btnTimKH_PTT";
            this.btnTimKH_PTT.Size = new System.Drawing.Size(98, 48);
            this.btnTimKH_PTT.TabIndex = 210;
            this.btnTimKH_PTT.Text = "Tìm Xe";
            this.btnTimKH_PTT.UseVisualStyleBackColor = false;
            this.btnTimKH_PTT.Click += new System.EventHandler(this.btnTimXe_PTT_Click);
            // 
            // txtXe_PTT
            // 
            this.txtXe_PTT.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXe_PTT.Location = new System.Drawing.Point(130, 269);
            this.txtXe_PTT.Name = "txtXe_PTT";
            this.txtXe_PTT.Size = new System.Drawing.Size(262, 27);
            this.txtXe_PTT.TabIndex = 209;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.DarkBlue;
            this.label31.Location = new System.Drawing.Point(23, 270);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(83, 24);
            this.label31.TabIndex = 208;
            this.label31.Text = "Tìm Xe:";
            // 
            // btnXemPhieuThuTien
            // 
            this.btnXemPhieuThuTien.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXemPhieuThuTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXemPhieuThuTien.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXemPhieuThuTien.Location = new System.Drawing.Point(1066, 259);
            this.btnXemPhieuThuTien.Name = "btnXemPhieuThuTien";
            this.btnXemPhieuThuTien.Size = new System.Drawing.Size(108, 48);
            this.btnXemPhieuThuTien.TabIndex = 207;
            this.btnXemPhieuThuTien.Text = "Xem";
            this.btnXemPhieuThuTien.UseVisualStyleBackColor = false;
            this.btnXemPhieuThuTien.Click += new System.EventHandler(this.btnXemPhieuThuTien_Click_1);
            // 
            // btnSuaPhieuThuTien
            // 
            this.btnSuaPhieuThuTien.BackColor = System.Drawing.Color.SeaGreen;
            this.btnSuaPhieuThuTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaPhieuThuTien.ForeColor = System.Drawing.SystemColors.Control;
            this.btnSuaPhieuThuTien.Location = new System.Drawing.Point(920, 259);
            this.btnSuaPhieuThuTien.Name = "btnSuaPhieuThuTien";
            this.btnSuaPhieuThuTien.Size = new System.Drawing.Size(108, 48);
            this.btnSuaPhieuThuTien.TabIndex = 206;
            this.btnSuaPhieuThuTien.Text = "Sửa";
            this.btnSuaPhieuThuTien.UseVisualStyleBackColor = false;
            this.btnSuaPhieuThuTien.Click += new System.EventHandler(this.btnSuaPhieuThuTien_Click_1);
            // 
            // btnXoaPhieuThuTien
            // 
            this.btnXoaPhieuThuTien.BackColor = System.Drawing.Color.SeaGreen;
            this.btnXoaPhieuThuTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaPhieuThuTien.ForeColor = System.Drawing.SystemColors.Control;
            this.btnXoaPhieuThuTien.Location = new System.Drawing.Point(778, 260);
            this.btnXoaPhieuThuTien.Name = "btnXoaPhieuThuTien";
            this.btnXoaPhieuThuTien.Size = new System.Drawing.Size(108, 48);
            this.btnXoaPhieuThuTien.TabIndex = 205;
            this.btnXoaPhieuThuTien.Text = "Xóa";
            this.btnXoaPhieuThuTien.UseVisualStyleBackColor = false;
            this.btnXoaPhieuThuTien.Click += new System.EventHandler(this.btnXoaPhieuThuTien_Click_1);
            // 
            // btnThemPhieuThuTien
            // 
            this.btnThemPhieuThuTien.BackColor = System.Drawing.Color.SeaGreen;
            this.btnThemPhieuThuTien.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemPhieuThuTien.ForeColor = System.Drawing.SystemColors.Control;
            this.btnThemPhieuThuTien.Location = new System.Drawing.Point(628, 259);
            this.btnThemPhieuThuTien.Name = "btnThemPhieuThuTien";
            this.btnThemPhieuThuTien.Size = new System.Drawing.Size(108, 48);
            this.btnThemPhieuThuTien.TabIndex = 204;
            this.btnThemPhieuThuTien.Text = "Thêm";
            this.btnThemPhieuThuTien.UseVisualStyleBackColor = false;
            this.btnThemPhieuThuTien.Click += new System.EventHandler(this.btnThemPhieuThuTien_Click_1);
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.DarkBlue;
            this.label32.Location = new System.Drawing.Point(633, 106);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(126, 24);
            this.label32.TabIndex = 203;
            this.label32.Text = "Số tiền thu :";
            // 
            // txtSoTienThu
            // 
            this.txtSoTienThu.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSoTienThu.Location = new System.Drawing.Point(835, 109);
            this.txtSoTienThu.Name = "txtSoTienThu";
            this.txtSoTienThu.Size = new System.Drawing.Size(342, 27);
            this.txtSoTienThu.TabIndex = 202;
            // 
            // dtpNgayTao_PTT
            // 
            this.dtpNgayTao_PTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgayTao_PTT.Location = new System.Drawing.Point(835, 47);
            this.dtpNgayTao_PTT.Name = "dtpNgayTao_PTT";
            this.dtpNgayTao_PTT.Size = new System.Drawing.Size(342, 27);
            this.dtpNgayTao_PTT.TabIndex = 201;
            this.dtpNgayTao_PTT.Value = new System.DateTime(2019, 12, 16, 0, 0, 0, 0);
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.ForeColor = System.Drawing.Color.DarkBlue;
            this.label33.Location = new System.Drawing.Point(633, 47);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(159, 24);
            this.label33.TabIndex = 200;
            this.label33.Text = "Ngày tạo phiếu:";
            // 
            // txtBienSo_PTT
            // 
            this.txtBienSo_PTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtBienSo_PTT.Location = new System.Drawing.Point(263, 167);
            this.txtBienSo_PTT.Name = "txtBienSo_PTT";
            this.txtBienSo_PTT.Size = new System.Drawing.Size(303, 27);
            this.txtBienSo_PTT.TabIndex = 198;
            // 
            // txtMaKH_PTT
            // 
            this.txtMaKH_PTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaKH_PTT.Location = new System.Drawing.Point(263, 109);
            this.txtMaKH_PTT.Name = "txtMaKH_PTT";
            this.txtMaKH_PTT.Size = new System.Drawing.Size(303, 27);
            this.txtMaKH_PTT.TabIndex = 197;
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.DarkBlue;
            this.label36.Location = new System.Drawing.Point(47, 170);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(116, 24);
            this.label36.TabIndex = 196;
            this.label36.Text = "Biển số xe:";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.DarkBlue;
            this.label37.Location = new System.Drawing.Point(47, 109);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(161, 24);
            this.label37.TabIndex = 195;
            this.label37.Text = "Mã khách hàng:";
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.DarkBlue;
            this.label38.Location = new System.Drawing.Point(47, 50);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(181, 24);
            this.label38.TabIndex = 194;
            this.label38.Text = "Mã phiếu thu tiền:";
            // 
            // txtIDPTT
            // 
            this.txtIDPTT.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtIDPTT.Location = new System.Drawing.Point(263, 50);
            this.txtIDPTT.Name = "txtIDPTT";
            this.txtIDPTT.Size = new System.Drawing.Size(303, 27);
            this.txtIDPTT.TabIndex = 199;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.DarkBlue;
            this.label41.Location = new System.Drawing.Point(590, 144);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(0, 24);
            this.label41.TabIndex = 193;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.DarkBlue;
            this.label42.Location = new System.Drawing.Point(590, 85);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(0, 24);
            this.label42.TabIndex = 192;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.DarkBlue;
            this.label39.Location = new System.Drawing.Point(1147, 173);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(0, 24);
            this.label39.TabIndex = 183;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.DarkBlue;
            this.label40.Location = new System.Drawing.Point(1147, 112);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(0, 24);
            this.label40.TabIndex = 182;
            // 
            // dgvPTT
            // 
            this.dgvPTT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPTT.Location = new System.Drawing.Point(544, 329);
            this.dgvPTT.Name = "dgvPTT";
            this.dgvPTT.RowHeadersWidth = 51;
            this.dgvPTT.RowTemplate.Height = 24;
            this.dgvPTT.Size = new System.Drawing.Size(633, 304);
            this.dgvPTT.TabIndex = 142;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.DarkBlue;
            this.label35.Location = new System.Drawing.Point(659, 119);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(116, 24);
            this.label35.TabIndex = 138;
            this.label35.Text = "Tình trạng:";
            // 
            // txtStatus
            // 
            this.txtStatus.Font = new System.Drawing.Font("Arial Narrow", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtStatus.Location = new System.Drawing.Point(830, 118);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(303, 27);
            this.txtStatus.TabIndex = 137;
            // 
            // frmDanhMuc
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1194, 685);
            this.Controls.Add(this.tbKhachHang);
            this.MaximizeBox = false;
            this.Name = "frmDanhMuc";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Danh Mục";
            this.tbKhachHang.ResumeLayout(false);
            this.tpKhachHang.ResumeLayout(false);
            this.tpKhachHang.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKhachHang)).EndInit();
            this.tpXe.ResumeLayout(false);
            this.tpXe.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKH_Xe)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe)).EndInit();
            this.tpKho.ResumeLayout(false);
            this.tpKho.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmSoLuongVatLieu)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvKho)).EndInit();
            this.tpPhieuSuaChua.ResumeLayout(false);
            this.tpPhieuSuaChua.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe_PSC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPSC)).EndInit();
            this.tpPhieuThuTien.ResumeLayout(false);
            this.tpPhieuThuTien.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe_PTT)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPTT)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tbKhachHang;
        private System.Windows.Forms.TabPage tpXe;
        private System.Windows.Forms.TabPage tpKhachHang;
        private System.Windows.Forms.Button btnTimKhachHang;
        private System.Windows.Forms.TextBox txtTimKhachHang;
        private System.Windows.Forms.DataGridView dgvKhachHang;
        private System.Windows.Forms.TabPage tpKho;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Button btnTimKho;
        private System.Windows.Forms.TextBox txtTimKho;
        private System.Windows.Forms.DataGridView dgvKho;
        private System.Windows.Forms.DataGridView dgvXe;
        private System.Windows.Forms.TabPage tpPhieuSuaChua;
        private System.Windows.Forms.TabPage tpPhieuThuTien;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.DataGridView dgvPSC;
        private System.Windows.Forms.DataGridView dgvPTT;
        private System.Windows.Forms.NumericUpDown nmSoLuongVatLieu;
        private System.Windows.Forms.DateTimePicker dtpNgayNhap;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtVatLieu;
        private System.Windows.Forms.TextBox txtMaSoVatLieu;
        private System.Windows.Forms.Button btnXemKhachHang;
        private System.Windows.Forms.Button btnSuaKhachHang;
        private System.Windows.Forms.Button btnXoaKhachHang;
        private System.Windows.Forms.Button btnThemKhachHang;
        private System.Windows.Forms.DateTimePicker dtpNgayGui;
        private System.Windows.Forms.TextBox txtTienNo;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtDienThoai;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTenKhachHang;
        private System.Windows.Forms.Label lbTenMon;
        private System.Windows.Forms.TextBox txtIDKhachHang;
        private System.Windows.Forms.Label lbID;
        private System.Windows.Forms.DataGridView dgvKH_Xe;
        private System.Windows.Forms.Button btnTimKH_Xe;
        private System.Windows.Forms.TextBox txtTimKH_Xe;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox txtHieuXe;
        private System.Windows.Forms.TextBox txtMaXe;
        private System.Windows.Forms.Button btnXemXe;
        private System.Windows.Forms.Button btxSuaXe;
        private System.Windows.Forms.Button btnXoaXe;
        private System.Windows.Forms.Button btnThemXe;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtIDKH_XE;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Button btnXemKho;
        private System.Windows.Forms.Button btnSuaKho;
        private System.Windows.Forms.Button btnXoaKho;
        private System.Windows.Forms.Button btnThemKho;
        private System.Windows.Forms.Button btnXemPSC;
        private System.Windows.Forms.Button btnSuaPSC;
        private System.Windows.Forms.Button btnXoaPSC;
        private System.Windows.Forms.Button btnThemPSC;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.TextBox txtTotalPricePSC;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.TextBox txtDonGiaPSC;
        private System.Windows.Forms.DateTimePicker dtpNgayTaoPSC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox txtTienCongPSC;
        private System.Windows.Forms.TextBox txtCarnumber_PSC;
        private System.Windows.Forms.ComboBox cbVatLieu;
        private System.Windows.Forms.TextBox txtNoiDungPSC;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtIDPSC;
        private System.Windows.Forms.Button btnXemPhieuThuTien;
        private System.Windows.Forms.Button btnSuaPhieuThuTien;
        private System.Windows.Forms.Button btnXoaPhieuThuTien;
        private System.Windows.Forms.Button btnThemPhieuThuTien;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.TextBox txtSoTienThu;
        private System.Windows.Forms.DateTimePicker dtpNgayTao_PTT;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.TextBox txtBienSo_PTT;
        private System.Windows.Forms.TextBox txtMaKH_PTT;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtIDPTT;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.DataGridView dgvXe_PSC;
        private System.Windows.Forms.Button btnTimXe_PSC;
        private System.Windows.Forms.TextBox txtXe_PSC;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.DataGridView dgvXe_PTT;
        private System.Windows.Forms.Button btnTimKH_PTT;
        private System.Windows.Forms.TextBox txtXe_PTT;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.TextBox txtStatus;
    }
}