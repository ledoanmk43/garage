﻿namespace GarageManagement.GarageManagement_GUI
{
    partial class frmPSC
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmPSC));
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.txtXe_PSC = new DevExpress.XtraEditors.TextEdit();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.cbVatLieu = new System.Windows.Forms.ComboBox();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.txtTienCongPSC = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.dtpNgayTaoPSC = new System.Windows.Forms.DateTimePicker();
            this.txtTotalPricePSC = new DevExpress.XtraEditors.TextEdit();
            this.txtDonGiaPSC = new DevExpress.XtraEditors.TextEdit();
            this.txtNoiDungPSC = new DevExpress.XtraEditors.TextEdit();
            this.txtCarnumber_PSC = new DevExpress.XtraEditors.TextEdit();
            this.txtIDPSC = new DevExpress.XtraEditors.TextEdit();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.dgvXe_PSC = new System.Windows.Forms.DataGridView();
            this.dgvPSC = new System.Windows.Forms.DataGridView();
            this.btnXemPSC = new DevExpress.XtraEditors.SimpleButton();
            this.btnTimXe_PSC = new DevExpress.XtraEditors.SimpleButton();
            this.btnXoaPSC = new DevExpress.XtraEditors.SimpleButton();
            this.btnSuaPSC = new DevExpress.XtraEditors.SimpleButton();
            this.btnThemPSC = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.txtXe_PSC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTienCongPSC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalPricePSC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDonGiaPSC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNoiDungPSC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCarnumber_PSC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIDPSC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe_PSC)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPSC)).BeginInit();
            this.SuspendLayout();
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Appearance.Options.UseFont = true;
            this.labelControl8.Location = new System.Drawing.Point(315, 21);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(49, 18);
            this.labelControl8.TabIndex = 20;
            this.labelControl8.Text = "Tìm xe";
            // 
            // txtXe_PSC
            // 
            this.txtXe_PSC.EditValue = "";
            this.txtXe_PSC.Location = new System.Drawing.Point(377, 16);
            this.txtXe_PSC.Name = "txtXe_PSC";
            this.txtXe_PSC.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtXe_PSC.Properties.Appearance.Options.UseFont = true;
            this.txtXe_PSC.Size = new System.Drawing.Size(390, 28);
            this.txtXe_PSC.TabIndex = 14;
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.labelControl10);
            this.groupControl1.Controls.Add(this.labelControl9);
            this.groupControl1.Controls.Add(this.cbVatLieu);
            this.groupControl1.Controls.Add(this.btnXoaPSC);
            this.groupControl1.Controls.Add(this.btnSuaPSC);
            this.groupControl1.Controls.Add(this.btnThemPSC);
            this.groupControl1.Controls.Add(this.labelControl6);
            this.groupControl1.Controls.Add(this.labelControl5);
            this.groupControl1.Controls.Add(this.txtTienCongPSC);
            this.groupControl1.Controls.Add(this.labelControl4);
            this.groupControl1.Controls.Add(this.labelControl3);
            this.groupControl1.Controls.Add(this.labelControl2);
            this.groupControl1.Controls.Add(this.labelControl1);
            this.groupControl1.Controls.Add(this.dtpNgayTaoPSC);
            this.groupControl1.Controls.Add(this.txtTotalPricePSC);
            this.groupControl1.Controls.Add(this.txtDonGiaPSC);
            this.groupControl1.Controls.Add(this.txtNoiDungPSC);
            this.groupControl1.Controls.Add(this.txtCarnumber_PSC);
            this.groupControl1.Controls.Add(this.txtIDPSC);
            this.groupControl1.Location = new System.Drawing.Point(12, 98);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(444, 505);
            this.groupControl1.TabIndex = 16;
            this.groupControl1.Text = "Điền thông tin khách hàng";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Appearance.Options.UseFont = true;
            this.labelControl10.Location = new System.Drawing.Point(15, 395);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(70, 18);
            this.labelControl10.TabIndex = 23;
            this.labelControl10.Text = "Tổng tiền";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Appearance.Options.UseFont = true;
            this.labelControl9.Location = new System.Drawing.Point(15, 345);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(74, 18);
            this.labelControl9.TabIndex = 22;
            this.labelControl9.Text = "Tiền công";
            // 
            // cbVatLieu
            // 
            this.cbVatLieu.FormattingEnabled = true;
            this.cbVatLieu.Location = new System.Drawing.Point(133, 145);
            this.cbVatLieu.Name = "cbVatLieu";
            this.cbVatLieu.Size = new System.Drawing.Size(230, 24);
            this.cbVatLieu.TabIndex = 21;
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Appearance.Options.UseFont = true;
            this.labelControl6.Location = new System.Drawing.Point(15, 245);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(67, 18);
            this.labelControl6.TabIndex = 5;
            this.labelControl6.Text = "Ngày tạo";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Appearance.Options.UseFont = true;
            this.labelControl5.Location = new System.Drawing.Point(15, 295);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(58, 18);
            this.labelControl5.TabIndex = 5;
            this.labelControl5.Text = "Đơn giá";
            // 
            // txtTienCongPSC
            // 
            this.txtTienCongPSC.Location = new System.Drawing.Point(133, 345);
            this.txtTienCongPSC.Name = "txtTienCongPSC";
            this.txtTienCongPSC.Size = new System.Drawing.Size(230, 22);
            this.txtTienCongPSC.TabIndex = 7;
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Appearance.Options.UseFont = true;
            this.labelControl4.Location = new System.Drawing.Point(15, 195);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(67, 18);
            this.labelControl4.TabIndex = 5;
            this.labelControl4.Text = "Nội dung";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Appearance.Options.UseFont = true;
            this.labelControl3.Location = new System.Drawing.Point(15, 145);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(55, 18);
            this.labelControl3.TabIndex = 5;
            this.labelControl3.Text = "Vật liệu";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Appearance.Options.UseFont = true;
            this.labelControl2.Location = new System.Drawing.Point(15, 95);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(79, 18);
            this.labelControl2.TabIndex = 5;
            this.labelControl2.Text = "Biển số xe";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.Options.UseFont = true;
            this.labelControl1.Location = new System.Drawing.Point(15, 45);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(66, 18);
            this.labelControl1.TabIndex = 5;
            this.labelControl1.Text = "ID phiếu ";
            // 
            // dtpNgayTaoPSC
            // 
            this.dtpNgayTaoPSC.Location = new System.Drawing.Point(133, 245);
            this.dtpNgayTaoPSC.Name = "dtpNgayTaoPSC";
            this.dtpNgayTaoPSC.Size = new System.Drawing.Size(230, 23);
            this.dtpNgayTaoPSC.TabIndex = 8;
            // 
            // txtTotalPricePSC
            // 
            this.txtTotalPricePSC.Location = new System.Drawing.Point(133, 395);
            this.txtTotalPricePSC.Name = "txtTotalPricePSC";
            this.txtTotalPricePSC.Properties.ReadOnly = true;
            this.txtTotalPricePSC.Size = new System.Drawing.Size(230, 22);
            this.txtTotalPricePSC.TabIndex = 7;
            // 
            // txtDonGiaPSC
            // 
            this.txtDonGiaPSC.Location = new System.Drawing.Point(133, 295);
            this.txtDonGiaPSC.Name = "txtDonGiaPSC";
            this.txtDonGiaPSC.Size = new System.Drawing.Size(230, 22);
            this.txtDonGiaPSC.TabIndex = 7;
            // 
            // txtNoiDungPSC
            // 
            this.txtNoiDungPSC.Location = new System.Drawing.Point(133, 195);
            this.txtNoiDungPSC.Name = "txtNoiDungPSC";
            this.txtNoiDungPSC.Size = new System.Drawing.Size(230, 22);
            this.txtNoiDungPSC.TabIndex = 6;
            // 
            // txtCarnumber_PSC
            // 
            this.txtCarnumber_PSC.Location = new System.Drawing.Point(133, 95);
            this.txtCarnumber_PSC.Name = "txtCarnumber_PSC";
            this.txtCarnumber_PSC.Size = new System.Drawing.Size(230, 22);
            this.txtCarnumber_PSC.TabIndex = 4;
            // 
            // txtIDPSC
            // 
            this.txtIDPSC.Location = new System.Drawing.Point(133, 45);
            this.txtIDPSC.Name = "txtIDPSC";
            this.txtIDPSC.Properties.ReadOnly = true;
            this.txtIDPSC.Size = new System.Drawing.Size(230, 22);
            this.txtIDPSC.TabIndex = 3;
            this.txtIDPSC.TextChanged += new System.EventHandler(this.txtIDPSC_TextChanged);
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Appearance.Options.UseFont = true;
            this.labelControl7.Location = new System.Drawing.Point(947, 104);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(317, 24);
            this.labelControl7.TabIndex = 18;
            this.labelControl7.Text = "Thông tin xe và phiếu sửa chữa";
            // 
            // dgvXe_PSC
            // 
            this.dgvXe_PSC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvXe_PSC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvXe_PSC.Location = new System.Drawing.Point(474, 144);
            this.dgvXe_PSC.Name = "dgvXe_PSC";
            this.dgvXe_PSC.RowHeadersWidth = 51;
            this.dgvXe_PSC.RowTemplate.Height = 24;
            this.dgvXe_PSC.Size = new System.Drawing.Size(1045, 225);
            this.dgvXe_PSC.TabIndex = 21;
            this.dgvXe_PSC.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvXe_PSC_CellContentClick);
            // 
            // dgvPSC
            // 
            this.dgvPSC.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPSC.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvPSC.Location = new System.Drawing.Point(474, 378);
            this.dgvPSC.Name = "dgvPSC";
            this.dgvPSC.RowHeadersWidth = 51;
            this.dgvPSC.RowTemplate.Height = 24;
            this.dgvPSC.Size = new System.Drawing.Size(1045, 225);
            this.dgvPSC.TabIndex = 21;
            this.dgvPSC.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvPSC_CellContentClick);
            // 
            // btnXemPSC
            // 
            this.btnXemPSC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnXemPSC.ImageOptions.Image")));
            this.btnXemPSC.Location = new System.Drawing.Point(474, 98);
            this.btnXemPSC.Name = "btnXemPSC";
            this.btnXemPSC.Size = new System.Drawing.Size(40, 40);
            this.btnXemPSC.TabIndex = 19;
            this.btnXemPSC.Text = "refresh";
            this.btnXemPSC.Click += new System.EventHandler(this.btnXemPSC_Click);
            // 
            // btnTimXe_PSC
            // 
            this.btnTimXe_PSC.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTimXe_PSC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnTimXe_PSC.ImageOptions.Image")));
            this.btnTimXe_PSC.Location = new System.Drawing.Point(780, 10);
            this.btnTimXe_PSC.Name = "btnTimXe_PSC";
            this.btnTimXe_PSC.Size = new System.Drawing.Size(41, 42);
            this.btnTimXe_PSC.TabIndex = 15;
            this.btnTimXe_PSC.Click += new System.EventHandler(this.btnTimXe_PSC_Click);
            // 
            // btnXoaPSC
            // 
            this.btnXoaPSC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnXoaPSC.ImageOptions.Image")));
            this.btnXoaPSC.Location = new System.Drawing.Point(170, 440);
            this.btnXoaPSC.Name = "btnXoaPSC";
            this.btnXoaPSC.Size = new System.Drawing.Size(100, 40);
            this.btnXoaPSC.TabIndex = 10;
            this.btnXoaPSC.Text = "Xoá";
            this.btnXoaPSC.Click += new System.EventHandler(this.btnXoaPSC_Click);
            // 
            // btnSuaPSC
            // 
            this.btnSuaPSC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnSuaPSC.ImageOptions.Image")));
            this.btnSuaPSC.Location = new System.Drawing.Point(310, 440);
            this.btnSuaPSC.Name = "btnSuaPSC";
            this.btnSuaPSC.Size = new System.Drawing.Size(100, 40);
            this.btnSuaPSC.TabIndex = 11;
            this.btnSuaPSC.Text = "Sửa";
            this.btnSuaPSC.Click += new System.EventHandler(this.btnSuaPSC_Click);
            // 
            // btnThemPSC
            // 
            this.btnThemPSC.ImageOptions.Image = ((System.Drawing.Image)(resources.GetObject("btnThemPSC.ImageOptions.Image")));
            this.btnThemPSC.Location = new System.Drawing.Point(30, 440);
            this.btnThemPSC.Name = "btnThemPSC";
            this.btnThemPSC.Size = new System.Drawing.Size(100, 40);
            this.btnThemPSC.TabIndex = 9;
            this.btnThemPSC.Text = "Tạo";
            this.btnThemPSC.Click += new System.EventHandler(this.btnThemPSC_Click);
            // 
            // frmPSC
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1190, 615);
            this.Controls.Add(this.dgvPSC);
            this.Controls.Add(this.dgvXe_PSC);
            this.Controls.Add(this.labelControl8);
            this.Controls.Add(this.btnXemPSC);
            this.Controls.Add(this.btnTimXe_PSC);
            this.Controls.Add(this.txtXe_PSC);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.labelControl7);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmPSC";
            this.Text = "Phiếu sửa chữa";
            ((System.ComponentModel.ISupportInitialize)(this.txtXe_PSC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTienCongPSC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTotalPricePSC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDonGiaPSC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtNoiDungPSC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCarnumber_PSC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIDPSC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvXe_PSC)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPSC)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.SimpleButton btnXemPSC;
        private DevExpress.XtraEditors.SimpleButton btnTimXe_PSC;
        private DevExpress.XtraEditors.TextEdit txtXe_PSC;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton btnXoaPSC;
        private DevExpress.XtraEditors.SimpleButton btnSuaPSC;
        private DevExpress.XtraEditors.SimpleButton btnThemPSC;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private System.Windows.Forms.DateTimePicker dtpNgayTaoPSC;
        private DevExpress.XtraEditors.TextEdit txtNoiDungPSC;
        private DevExpress.XtraEditors.TextEdit txtCarnumber_PSC;
        private DevExpress.XtraEditors.TextEdit txtIDPSC;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit txtTienCongPSC;
        private DevExpress.XtraEditors.TextEdit txtTotalPricePSC;
        private System.Windows.Forms.ComboBox cbVatLieu;
        private System.Windows.Forms.DataGridView dgvXe_PSC;
        private System.Windows.Forms.DataGridView dgvPSC;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit txtDonGiaPSC;
    }
}